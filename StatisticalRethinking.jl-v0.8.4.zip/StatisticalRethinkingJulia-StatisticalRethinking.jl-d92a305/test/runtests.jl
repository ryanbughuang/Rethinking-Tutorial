using StatisticalRethinking
using Test

println("Tests are executed in docs job.")

@test 1 == 1
