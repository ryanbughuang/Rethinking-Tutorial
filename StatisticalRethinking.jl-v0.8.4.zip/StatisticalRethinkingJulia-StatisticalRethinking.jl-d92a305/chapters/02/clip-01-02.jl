using StatisticalRethinking

ways  = [0, 3, 8, 9, 0];

ways/sum(ways)

d = Binomial(9, 0.5)

pdf(d, 6)

# This file was generated using Literate.jl, https://github.com/fredrikekre/Literate.jl

